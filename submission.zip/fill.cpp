#include <cassert>
#include "fill.h"

// TODO: implement constructors

Fill::~Fill() {
}

// TODO: implement member functions
