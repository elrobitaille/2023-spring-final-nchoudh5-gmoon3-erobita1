#ifndef FILL_H
#define FILL_H

#include <string>
#include "image.h"

class Fill {
private:
  // TODO: add fields to represent the fill

public:
  // TODO: add appropriate constructors
  ~Fill();

  // TODO: add appropriate member functions
};

#endif // FILL_H
