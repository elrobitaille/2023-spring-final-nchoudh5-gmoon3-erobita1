#ifndef COLOR_H
#define COLOR_H

#include <cstdint>
#include <cassert>

struct Color {
  uint8_t r, g, b;

  Color(uint8_t r = 0, uint8_t g = 0, uint8_t b = 0) : r(r), g(g), b(b) { }

  // Multiply a Color by a scalar
  Color operator*(float scalar) const {
    return Color(r*scalar, g*scalar, b*scalar);
  }

  // Add two Colors together
  Color operator+(const Color &other) const {
    return Color(r+other.r, g+other.g, b+other.b);
  }

  // Clamp the values of a Color to be between 0 and 255
  void clamp() {
    r = std::max(0, std::min(255, static_cast<int>(r)));
    g = std::max(0, std::min(255, static_cast<int>(g)));
    b = std::max(0, std::min(255, static_cast<int>(b)));
  }
};



#endif // COLOR_H
